@echo off
echo =============================================
echo   Starting OneNote to PDF Conversion (Maven)
echo =============================================
if not exist "AcademicNotes.one" (
  echo ⚠️ WARNING: "AcademicNotes.one" not found.
  echo Creating placeholder. Replace this with your actual OneNote file!
  echo Placeholder > "AcademicNotes.one"
)
call mvn compile exec:java
pause
