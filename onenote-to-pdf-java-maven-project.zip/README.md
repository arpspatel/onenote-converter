# Microsoft OneNote to PDF Converter Script (Java + Aspose.Note)

This project contains an automated converter script to safely render binary Microsoft OneNote files (`.one`) directly into highly stylized, vectors-compatible PDF document sheets.

---

## 🛠 Prerequisites

1. **Java Development Kit (JDK 17 or higher)**
   - Verify installation: `java -version`
2. **Apache Maven** installed on your workstation pathway.
3. **An input OneNote Document** (`.one`) file.

---

## 📖 Quickstart Guide

### 📂 Step 1: Copy your Notebook File
Rename or copy your target OneNote file into this root project folder and ensure it matches the configured input filename:
- **File Name expected**: `AcademicNotes.one`
- *(Alternatively, you can edit `src/main/java/com/example/OneNoteToPdfConverter.java` to point to any custom path)*

### 🚀 Step 2: Compile & Run with Maven
Run the following script to compile your code and start the conversion engine:
```bash
mvn compile exec:java
```
*(Optional) To build a standalone executable jar package with dependencies, use `mvn package`.*

---

## ⚙️ Advanced Configuration (In Java Source File)

The generated script is loaded with robust options you configured inside Google AI Studio:

1. **Encrypted Notebook Compatibility**:
   - Includes custom loading blocks so that password decryption does not halt execution.
2. **High Integrity Compliance**:
   - Configured with PDF compliance formatting (**Standard 1.5**), securing layout coordinate tables and line styles.
3. **Vector/Asset Optimization**:
   - Embedded screenshot compressing and Jpeg rendering level configured to an opt-in **90%** quality threshold.
4. **Custom Fonts Mapping (Crucial on Linux / Docker Environments)**:
   - If your PDF generates blank pages or weird squares instead of bulleted lists, it means your Linux workspace lacks standard Microsoft fonts. 
   - Specify a target TTF directory in `saveOptions.setFontFolder("/path/to/fonts")`.

---

## 📜 Aspose Licensing Information
By default, Aspose.Note operates in **Evaluation Trial Mode**, which appends an evaluation watermark banner to output PDFs and only allows translating a subset of your workspace folders.
To remove evaluation flags, obtain a standard or trial license (from [Aspose.com](https://www.aspose.com)) and invoke:
```java
License license = new License();
license.setLicense("Aspose.Note.lic");
```
*Ensure you read the license file into memory BEFORE initializing the `Document` class!*
