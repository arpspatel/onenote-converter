#!/usr/bin/env bash
echo "============================================="
echo "  Starting OneNote to PDF Conversion (Maven) "
echo "============================================="
# Ensure correct input file is placed
if [ ! -f "AcademicNotes.one" ]; then
  echo "⚠️  WARNING: 'AcademicNotes.one' not found."
  echo "Creating a dummy placeholder mock node so build doesn't throw a fatal file error."
  echo "Please replace it with your REAL OneNote .one file to convert!"
  echo "Placeholder" > "AcademicNotes.one"
fi

mvn compile exec:java
